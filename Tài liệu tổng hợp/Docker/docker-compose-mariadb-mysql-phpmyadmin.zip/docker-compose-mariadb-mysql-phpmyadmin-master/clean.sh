#/bin/bash

docker-compose down
sudo rm -rf ./mariadb10/
sudo rm -rf ./mysql5/
sudo rm -rf ./mysql8/
