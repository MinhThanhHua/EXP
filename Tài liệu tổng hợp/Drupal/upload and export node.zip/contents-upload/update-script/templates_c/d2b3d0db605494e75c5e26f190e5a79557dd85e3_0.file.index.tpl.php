<?php
/* Smarty version 3.1.34-dev-7, created on 2020-03-10 07:59:56
  from 'C:\xampp\htdocs\contents-upload\update-script\templates\index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e673aec412cc8_23012311',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd2b3d0db605494e75c5e26f190e5a79557dd85e3' => 
    array (
      0 => 'C:\\xampp\\htdocs\\contents-upload\\update-script\\templates\\index.tpl',
      1 => 1582614148,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e673aec412cc8_23012311 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'pageTitle');?>
</title>
</head>
<body style="background:<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'grayBgColor');?>
;">

<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['program']->value, 'row');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['row']->value) {
?>
	<h2><a href="./<?php echo $_smarty_tpl->tpl_vars['row']->value['nid'];?>
/"><?php echo $_smarty_tpl->tpl_vars['row']->value['title'];?>
</a></h2>
	<p><?php echo $_smarty_tpl->tpl_vars['row']->value['nid'];?>
</p>
	<hr>
<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
</body>
</html>
<?php }
}
