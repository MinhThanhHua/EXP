<?php

require dirname(__FILE__) .  '\..\vendor\autoload.php';

$filename = dirname(__FILE__) . "\param.dat";
$outputdir = dirname(__FILE__) . "\output";
$error_log = dirname(__FILE__) . "\debug.log";

$server = 'http://localhost/drupal/drupal-8.8.2';


$id = $argv[1];
$lang = $argv[2];

exec("echo $id >> $filename");

sleep(5);

/*
	個別データの取得とHTMLの出力
*/
$url = "$server/${lang}/node/${id}?_format=json";

//print_r($http_response_header);exit;
if (!$json = @file_get_contents($url)) {
	echo 'Node not exists';
	exit;
}
$arr = json_decode($json,true);
//	言語が一致しない場合は未翻訳のため終了
if ($arr['langcode']['0']['value'] != $lang)exit;

//	ディレクトリの存在確認。なければ作成
$outputfile = $outputdir . "\\${lang}\\programs\\${id}";
echo 'in';
var_dump($outputfile);
if (!file_exists($outputfile)) {
	mkdir($outputfile,0755, true);
};

$outputfile .= "\index.html";
$smarty = new Smarty();
$smarty->setTemplateDir(dirname(__FILE__) . '\templates');
$smarty->setCompileDir(dirname(__FILE__) . '\templates_c');
$smarty->assign('program',$arr);
$output = $smarty->fetch('detail.tpl');
file_put_contents($outputfile,$output);

error_log($outputfile,"3",$error_log);

/*
	一覧の出力
*/
$url = "$server/search/$lang";
$json = file_get_contents($url);
$arr = json_decode($json,true);

$outputfile = $outputdir . "\\$lang\programs\index.html";
$smarty = new Smarty();
$smarty->setTemplateDir(dirname(__FILE__) . '\templates');
$smarty->setCompileDir(dirname(__FILE__) . '\templates_c');
$smarty->assign('program',$arr);
$output = $smarty->fetch('index.tpl');
file_put_contents($outputfile,$output);

?>
