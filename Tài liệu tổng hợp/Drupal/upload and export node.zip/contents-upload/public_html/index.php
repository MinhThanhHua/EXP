<?php

$script =  dirname(__FILE__) . "\..\update-script\convert.php";
//preg_match('|' . dirname($_SERVER['SCRIPT_NAME']) . '/([\w%/]*)|', $_SERVER['REQUEST_URI'], $matches);
$paths = explode('/', $_SERVER['REQUEST_URI']);
$id = isset($paths[2]) ? htmlspecialchars($paths[4]) : null;
var_dump($paths);
var_dump($id);
switch (1) {
case 'get:node':
//  if ($id) echo "ユーザー #{$id} 取得";
//  else echo 'ユーザー 一覧';
  break;
case '1':
  $cmd = "php $script $id $paths[5]";
  
	file_put_contents(dirname(__FILE__) . '/../cmd.txt',$cmd);	//	for setting
  $test = exec($cmd);
  var_dump($cmd);
  break;
case 'put:user':
  echo "ユーザー #{$id} 更新";
  break;
case 'delete:user':
  echo "ユーザー #{$id} 削除";
  break;
}
