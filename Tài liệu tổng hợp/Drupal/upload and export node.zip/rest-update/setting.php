<?php

$base_url = 'http://localhost/drupal/drupal-8.8.2';
$user = 'thanhhm';
$pass = 'thanhhm95';