<?php
require_once('./vendor/autoload.php');

/*
	ディレクトリにあるdata.csvを開いてデータを取得
	REST APIでDrupalにデータを登録するモジュール
*/

/*
Important
Place setting file as setting.php on same directory of this php file.

Write those variables on the setting.php for your own settings.

$base_url = 'http://foo.bar.jp';
$user = 'admin';
$pass = 'yourpassword';

*/

require_once('./setting.php');

use GuzzleHttp\Client;
use GuzzleHttp\Cookie\CookieJar;
use GuzzleHttp\Exception\RequestException;

use League\Csv\Reader;
use League\Csv\Statement;



$fieldnames = [
	'id' => 'field_id',
	'active' => 'field_active',
	'title' => 'title',
	'list_title' => 'field_list_title',
	'list_detail' => 'field_list_detail',
	'body' => 'field_body',
	'url' => 'field_url',
	'category' => 'field_category',
	'caption' => 'field_caption',
	'type' => 'field_type',
	'periods_text' => 'field_period_text',
	'locations_text' => 'field_location',
];

$fieldnamesmulti = [
	'area' => 'field_area',
	'entry_fee' => 'field_entry_fee',
	'project_formats' => 'field_project_format',
	'tags' => 'field_tag',
	'keywords' => 'field_keyword',

];

$csv = Reader::createFromPath('./ja.csv', 'r');
$csv->setHeaderOffset(0);


//$stmt = new Statement();$records = $stmt->limit(10)->process($csv); // for test. Update only 10 records
$records = $csv->getRecords();

foreach ($records as $record) {
	foreach ($fieldnames as $key => $value){
		$fields[$value] =  [['value' => $record[$key]]];	//	通常フィールドの格納
	}
	//	detail_infoの格納
	$field_detail_infos = [];
	for($i=0;$i<10;$i++){
		if (!($record["detail_info_${i}_name"] == '' && $record["detail_info_${i}_value"] == "")){
			$field_detail_infos[] =  ['first'		=> $record["detail_info_${i}_name"],
																'second'	=> $record["detail_info_${i}_value"]
																];
		}
	}
	$fields['field_detail_info'] =  $field_detail_infos;

	//	開催期間の格納
	$periods = [];
	$arr = json_decode($record['periods'],true);
	date_default_timezone_set('Asia/Tokyo');
	for($i=0;$i<count($arr);$i++){
		$periods[] = ['value'		=> date("Y-m-d\TH:i:s+09:00", $arr[$i]["from"]/1000),
									'end_value'	=> date("Y-m-d\TH:i:s+09:00", $arr[$i]["to"]/1000)
									];
	}
	$fields['field_period'] =  $periods;
	//	複数アイテムがあるフィールドの格納
	foreach ($fieldnamesmulti as $key => $value){
		$fields[$value] = multivalue($record[$key]);
	}

	// $fields['langcode'] = [['langcode' => 'en']];
	//	固定項目の格納
	$fields['type'] = [['target_id' => 'program']];
	$nodes[] = $fields;
}
//print_r($nodes);exit;


$jar = new CookieJar();

try {

  $client = new Client([
    'base_url' => $base_url,
    'cookies' => true,
    'allow_redirects' => true,
    'debug' => false
  ]);

  $response = $client->post($base_url . '/user/login', [
    "form_params" => [
      "name"=> $user,
      "pass"=> $pass,
      'form_id' => 'user_login_form'
    ],
    'cookies' => $jar
  ]);

  $token = $client->get($base_url . '/rest/session/token', [
    'cookies' => $jar
  ])->getBody(TRUE);

  $token = $token->__toString();

	foreach ($nodes as $node){
		echo "ID = " . $node['field_id'][0]['value'] . "\n";
		$response = $client->post($base_url . '/node', [
			'cookies' => $jar,
			'headers' => [
			'Content-type' => 'application/json',
			'X-CSRF-Token' => $token,
			],
			'query' => ["_format" => "json"],
			'json' => $node,
			
		]);

		if ($response->getStatusCode() == 201) {
			print "Node creation successful!\n";
		} else {
			print "unsuccessful... keep trying\n";
			print_r(get_defined_vars());
//			print_r($response);
		}
	}
	
} catch(RequestException $e) {
	var_dump($e);
	echo $e->getRequest();
	echo "\n\n";
	if ($e->hasResponse()) {
	echo $e->getResponse();
	}
}

function multivalue($value){
	$arr = json_decode($value);
	if ($arr == '')return;
	$ret = [];
	for($i=0;$i<count($arr);$i++){
		$ret[] = ['value'		=> $arr[$i]];
	}
	return $ret;
}
?>
