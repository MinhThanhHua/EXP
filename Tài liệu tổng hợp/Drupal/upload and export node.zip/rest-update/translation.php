<?php
require_once('./vendor/autoload.php');

/*
	ディレクトリにあるdata.csvを開いてデータを取得
	REST APIでDrupalにデータを登録するモジュール
*/

/*
Important
Place setting file as setting.php on same directory of this php file.

Write those variables on the setting.php for your own settings.

$base_url = 'http://foo.bar.jp';
$user = 'admin';
$pass = 'yourpassword';

*/

require_once('./setting.php');

use GuzzleHttp\Client;
use GuzzleHttp\Cookie\CookieJar;
use GuzzleHttp\Exception\RequestException;

use League\Csv\Reader;
use League\Csv\Statement;

use GuzzleHttp\Psr7\Request;
use GuzzleHttp\Psr7;
use GuzzleHttp\Psr7\Stream;

//ApacheでPATCH methodを許可すること

$lang = 'en';

$fieldnames = [
	'id' => 'field_id',
	'active' => 'field_active',
	'title' => 'title',
	'list_title' => 'field_list_title',
	'list_detail' => 'field_list_detail',
	'body' => 'field_body',
	'url' => 'field_url',
	'caption' => 'field_caption',
	'periods_text' => 'field_period_text',
	'locations_text' => 'field_location',
];

$fieldnamesmulti = [
	'tags' => 'field_tag',
	'keywords' => 'field_keyword',
];

//	日本語の全データを取得して、idとDrupalのIDの対比表を作成
$json = file_get_contents($base_url . '/search/ja/');

$arr = json_decode($json,true);var_dump($arr);
for ($i=0;$i<count($arr);$i++){
	$map[$arr[$i]['field_id']] = $arr[$i]['nid'];
}

//	日本語の記事IDとの対比表を取得
$ja_en_map_csv = Reader::createFromPath('./ja_en_map.csv', 'r');
$ja_en_map_csv->setHeaderOffset(0);
$ja_en_maps = $ja_en_map_csv->getRecords();

foreach ($ja_en_maps as $ja_en_map){
	$arr_ja_en_maps[$ja_en_map['en_old_id']] = $ja_en_map['ja_old_id'];
}

$csv = Reader::createFromPath('./en.csv', 'r');
$csv->setHeaderOffset(0);

//$stmt = new Statement();$records = $stmt->limit(1)->process($csv);
$records = $csv->getRecords();

$nodes = [];
$nids = [];

foreach ($records as $record) {
	//	日本語の記事IDとの対比表にIDがなければスキップ
	if (!array_key_exists($record['old_id'],$arr_ja_en_maps))continue;
	//	ある場合はidを置換
	$record['id'] = $arr_ja_en_maps[$record['old_id']];
	
	//	英語データのidに該当するデータが日本語になければスキップ
	if (!array_key_exists($record['id'],$map))continue;
	//	ある場合はnidとidの対比表を作成
	$nids[$record['id']] = $map[$record['id']];
	
	foreach ($fieldnames as $key => $value){
		$fields[$value] =  [['value' => $record[$key]]];	//	通常フィールドの格納
	}
	//	detail_infoの格納
	$field_detail_infos = [];
	for($i=0;$i<10;$i++){
		if (!($record["detail_info_${i}_name"] == '' && $record["detail_info_${i}_value"] == "")){
			$field_detail_infos[] =  ['first'		=> $record["detail_info_${i}_name"],
																'second'	=> $record["detail_info_${i}_value"]
																];
		}
	}
	$fields['field_detail_info'] =  $field_detail_infos;
	
	//	複数アイテムがあるフィールドの格納
	foreach ($fieldnamesmulti as $key => $value){
		$fields[$value] = multivalue($record[$key]);
	}
	
	//	固定項目の格納
	$fields['langcode'] = [['value' => 'en']];
//	$fields['nid'] = [['value' => '1935']];
	$fields['type'] = [['target_id' => 'program']];
	$nodes[] = $fields;
}

//print_r($nodes);exit;


$jar = new CookieJar();

try {

  $client = new Client([
    'base_url' => $base_url,
    'cookies' => true,
    'allow_redirects' => true,
    'debug' => false
  ]);

  $response = $client->post($base_url . '/user/login', [
    "form_params" => [
      "name"=> $user,
      "pass"=> $pass,
      'form_id' => 'user_login_form'
    ],
    'cookies' => $jar
  ]);

  $token = $client->get($base_url . '/rest/session/token', [
    'cookies' => $jar
  ])->getBody(TRUE);

  $token = $token->__toString();

	foreach ($nodes as $node){
		$nid = $map[$node['field_id'][0]['value']];
//		print_r($node);exit;
//		echo $node['field_id'][0]['value'];exit;
		//	翻訳データ作成APIの呼び出し
		$trans = $client->get($base_url . '/node/' . $nid, [
		'cookies' => $jar
	  ])->getBody();
	  var_dump($base_url . '/node/' . $nid);
	  var_dump($trans);
	  
//		print_r($node);exit;
		// $response = $client->patch($base_url . '/en/node/1943', [
		// $response = $client->patch($base_url . '/node/' . $nid . '/translations/add/ja/' . $lang, [
		// $response = $client->patch($base_url . '/' . $lang . '/node/' . $nid, [
		// 	'cookies' => $jar,
		// 	'headers' => [
		// 	'Content-type' => 'application/json',
		// 	'X-CSRF-Token' => $token,
		// 	],
		// 	'query' => ["_format" => "json"],
		// 	'json' => $node
		// ]);

		$translation = $trans->addTranslation('en',  $node);
    	$trans->save();
		
		if ($response->getStatusCode() == 200) {
			print "Node creation successful! nid = ${nid}\n";
		} else {
			print "unsuccessful... keep trying\n";
//			print_r(get_defined_vars());
//			print_r($response);
		}
	}
	
} catch(RequestException $e) {
	var_dump($e);
	echo $e->getRequest();
	echo "\n\n";
	if ($e->hasResponse()) {
	echo $e->getResponse();
	}
}

function multivalue($value){
	$arr = json_decode($value);
	$ret = [];
	for($i=0;$i<count($arr);$i++){
		$ret[] = ['value'		=> $arr[$i]];
	}
	return $ret;
}
?>
